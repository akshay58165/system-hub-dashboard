import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Terminal, 
  GitBranch, 
  Layers, 
  Database, 
  Search, 
  Settings, 
  Bell, 
  Activity, 
  Clock, 
  TrendingUp, 
  Cpu, 
  Github,
  Wifi,
  ExternalLink,
  Laptop
} from 'lucide-react';

import { GitHubRepo, VercelProject, SupabaseProject, SystemEvent } from './types';
import { 
  initialGitHubRepos, 
  initialVercelProjects, 
  initialSupabaseProject, 
  initialSystemEvents 
} from './data';

import Overview from './components/Overview';
import GithubView from './components/GithubView';
import VercelView from './components/VercelView';
import SupabaseView from './components/SupabaseView';
import CommandPalette from './components/CommandPalette';

export default function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'github' | 'vercel' | 'supabase'>('overview');
  const [repos, setRepos] = useState<GitHubRepo[]>(initialGitHubRepos);
  const [vercelProjects, setVercelProjects] = useState<VercelProject[]>(initialVercelProjects);
  const [supabase, setSupabase] = useState<SupabaseProject>(initialSupabaseProject);
  const [events, setEvents] = useState<SystemEvent[]>(initialSystemEvents);
  
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [timeStr, setTimeStr] = useState('');

  // Keyboard shortcut for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Update clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Simulate real-time background events (e.g. background database actions, commits, deployments)
  useEffect(() => {
    const interval = setInterval(() => {
      // Pick a random event type
      const eventTypes = ['api', 'metrics', 'commit'] as const;
      const chosenType = eventTypes[Math.floor(Math.random() * eventTypes.length)];

      if (chosenType === 'api') {
        // Generate new API log in Supabase
        const apiPaths = [
          '/rest/v1/posts?select=*',
          '/rest/v1/transactions?id=eq.txn_9d1a3b8',
          '/auth/v1/user',
          '/rest/v1/profiles?subscription_tier=eq.Pro'
        ];
        const randomPath = apiPaths[Math.floor(Math.random() * apiPaths.length)];
        const randomMethod = randomPath.includes('auth') || randomPath.includes('transactions') ? 'POST' : 'GET';
        const randomStatus = Math.random() > 0.05 ? 200 : 401;
        const latency = Math.floor(Math.random() * 80) + 8;

        const newLog = {
          id: `log-${Date.now()}`,
          method: randomMethod as 'GET' | 'POST',
          path: randomPath,
          status: randomStatus,
          latencyMs: latency,
          timestamp: new Date().toISOString()
        };

        setSupabase(prev => ({
          ...prev,
          apiLogs: [newLog, ...prev.apiLogs.slice(0, 15)],
          metrics: {
            ...prev.metrics,
            activeConnections: Math.max(10, Math.min(40, prev.metrics.activeConnections + (Math.random() > 0.5 ? 1 : -1)))
          }
        }));

        if (randomStatus === 401) {
          addEvent({
            id: `evt-bg-err-${Date.now()}`,
            source: 'supabase',
            type: 'warning',
            message: `Supabase API: Unauthorized request blocked on ${randomPath}`,
            timestamp: new Date().toISOString()
          });
        }
      } else if (chosenType === 'metrics') {
        // Slightly fluctuate hardware metrics
        setSupabase(prev => ({
          ...prev,
          metrics: {
            ...prev.metrics,
            cpuUsage: Math.max(5, Math.min(90, prev.metrics.cpuUsage + Math.floor(Math.random() * 6) - 3)),
            memoryUsage: Math.max(25, Math.min(80, prev.metrics.memoryUsage + Math.floor(Math.random() * 4) - 2))
          }
        }));
      } else if (chosenType === 'commit') {
        // Simulate minor commit in background on main-app repo
        const commitMessages = [
          'chore: improve tailwind utility class loading',
          'docs: update supabase migration guidelines in README.md',
          'refactor: optimize edge function payload sanitizers',
          'style: adjust dialog borders to clean charcoal colors'
        ];
        const message = commitMessages[Math.floor(Math.random() * commitMessages.length)];
        const hash = Math.random().toString(16).substring(2, 9);
        const authors = ['alex-dev', 'tony-design', 'sarah-ops'];
        const author = authors[Math.floor(Math.random() * authors.length)];

        const newCommit = {
          id: `c-bg-${Date.now()}`,
          message,
          author,
          date: new Date().toISOString(),
          hash
        };

        setRepos(prev => prev.map(r => {
          if (r.name === 'main-app') {
            return {
              ...r,
              commits: [newCommit, ...r.commits.slice(0, 15)]
            };
          }
          return r;
        }));

        addEvent({
          id: `evt-bg-cmt-${Date.now()}`,
          source: 'github',
          type: 'info',
          message: `GitHub: ${author} pushed commit "${message}" to main-app (${hash})`,
          timestamp: new Date().toISOString()
        });
      }

    }, 20000); // Trigger every 20 seconds

    return () => clearInterval(interval);
  }, []);

  const addEvent = (evt: SystemEvent) => {
    setEvents(prev => [evt, ...prev.slice(0, 29)]);
  };

  const handleUpdateRepo = (repoId: string, updatedRepo: Partial<GitHubRepo>) => {
    setRepos(prev => prev.map(r => r.id === repoId ? { ...r, ...updatedRepo } : r));
  };

  const handleUpdateProject = (projectId: string, updatedProject: Partial<VercelProject>) => {
    setVercelProjects(prev => prev.map(p => p.id === projectId ? { ...p, ...updatedProject } : p));
  };

  const handleUpdateSupabase = (updated: Partial<SupabaseProject>) => {
    setSupabase(prev => ({ ...prev, ...updated }));
  };

  // Helper linking GitHub workflow completion to triggering Vercel build
  const triggerVercelDeploy = (projectName: string) => {
    const vercelProj = vercelProjects.find(p => p.name === projectName);
    if (!vercelProj) return;

    // Trigger vercel project deploy sequence
    const newDeploymentId = `vdep-auto-${Date.now()}`;
    const newDeployment = {
      id: newDeploymentId,
      url: `${vercelProj.name}-git-main.vercel.app`,
      branch: vercelProj.gitBranch,
      commitMessage: 'git push: automatic deployment from GitHub workflow integration trigger',
      status: 'ready' as const,
      createdAt: new Date().toISOString(),
      creator: 'github-bot',
      duration: '52s',
      logs: [
        'Deployment automatically triggered by Git webhook.',
        'Pulling build hook outputs...',
        'Compiling Next.js targets...',
        'Edge servers synchronized!',
        'Active routing rule switched successfully.'
      ]
    };

    handleUpdateProject(vercelProj.id, {
      status: 'ready',
      updatedAt: new Date().toISOString(),
      deployments: [newDeployment, ...vercelProj.deployments]
    });

    addEvent({
      id: `evt-v-auto-${Date.now()}`,
      source: 'vercel',
      type: 'success',
      message: `Vercel: Auto-deployment of "${vercelProj.name}" is LIVE following GitHub action merge!`,
      timestamp: new Date().toISOString()
    });
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200 antialiased font-sans">
      
      {/* Top Main Header */}
      <header className="border-b border-neutral-850 bg-neutral-950 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Logo & title */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center">
              <span className="p-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-emerald-400 font-bold tracking-tight text-xs font-mono">
                GVS
              </span>
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                Developer Cockpit
                <span className="px-1.5 py-0.2 bg-emerald-950 text-emerald-400 font-mono text-[9px] uppercase font-semibold rounded-full border border-emerald-900">
                  v1.8
                </span>
              </h1>
              <p className="text-[10px] text-neutral-500 font-mono hidden sm:block">Integrated system dashboard for GitHub, Vercel & Supabase</p>
            </div>
          </div>

          {/* Quick Search bar */}
          <div className="flex-1 max-w-sm hidden md:block">
            <button 
              onClick={() => setIsPaletteOpen(true)}
              className="w-full flex items-center justify-between gap-3 px-3.5 py-1.5 bg-neutral-900 hover:bg-neutral-850 text-neutral-500 hover:text-neutral-400 border border-neutral-800 rounded-lg transition text-xs font-mono"
            >
              <div className="flex items-center gap-2">
                <Search className="h-3.5 w-3.5 text-neutral-500" />
                <span>Search projects or schemas...</span>
              </div>
              <span className="text-[9px] text-neutral-600 font-semibold uppercase bg-neutral-950 px-1.5 py-0.5 border border-neutral-850 rounded">
                ⌘K
              </span>
            </button>
          </div>

          {/* Real-time UTC metrics / clock */}
          <div className="flex items-center gap-4 shrink-0 font-mono text-[11px] text-neutral-400">
            <div className="flex items-center gap-1.5 text-neutral-500 bg-neutral-900 border border-neutral-850 px-2.5 py-1 rounded-lg">
              <Clock className="h-3.5 w-3.5" />
              <span>{timeStr || 'Loading...'}</span>
            </div>

            <div className="hidden lg:flex items-center gap-1.5 text-neutral-400">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>All Cloud Systems Nominal</span>
            </div>
          </div>

        </div>
      </header>

      {/* Main Tab Controller Bar */}
      <nav className="border-b border-neutral-900 bg-neutral-950/60 backdrop-blur-md sticky top-16 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4 py-2 overflow-x-auto">
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'overview'
                    ? 'bg-neutral-900 border border-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/30'
                }`}
              >
                <Activity className="h-3.5 w-3.5" />
                <span>Overview</span>
              </button>

              <button
                onClick={() => setActiveTab('github')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'github'
                    ? 'bg-neutral-900 border border-neutral-850 text-blue-400'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/30'
                }`}
              >
                <GitBranch className="h-3.5 w-3.5" />
                <span>GitHub Repos</span>
              </button>

              <button
                onClick={() => setActiveTab('vercel')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'vercel'
                    ? 'bg-neutral-900 border border-neutral-850 text-amber-400'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/30'
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Vercel Deployments</span>
              </button>

              <button
                onClick={() => setActiveTab('supabase')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition flex items-center gap-1.5 ${
                  activeTab === 'supabase'
                    ? 'bg-neutral-900 border border-neutral-850 text-emerald-400'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/30'
                }`}
              >
                <Database className="h-3.5 w-3.5" />
                <span>Supabase Database</span>
              </button>
            </div>

            <div className="flex items-center gap-1 font-mono text-[10px] text-neutral-500 shrink-0">
              <span className="hidden sm:inline">User email:</span>
              <span className="px-2 py-0.5 bg-neutral-900 border border-neutral-850 text-neutral-300 rounded">
                typeakshay@gmail.com
              </span>
            </div>
          </div>
        </div>
      </nav>

      {/* Primary Application Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === 'overview' && (
              <Overview 
                repos={repos} 
                vercelProjects={vercelProjects} 
                supabase={supabase} 
                events={events}
                onTabChange={setActiveTab}
              />
            )}

            {activeTab === 'github' && (
              <GithubView 
                repos={repos} 
                onAddEvent={addEvent} 
                onUpdateRepo={handleUpdateRepo}
                onTriggerDeploy={triggerVercelDeploy}
              />
            )}

            {activeTab === 'vercel' && (
              <VercelView 
                projects={vercelProjects} 
                onAddEvent={addEvent} 
                onUpdateProject={handleUpdateProject}
              />
            )}

            {activeTab === 'supabase' && (
              <SupabaseView 
                supabase={supabase} 
                onAddEvent={addEvent} 
                onUpdateSupabase={handleUpdateSupabase}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Command Palette Modal */}
      <CommandPalette 
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        repos={repos}
        vercelProjects={vercelProjects}
        supabase={supabase}
        onTabChange={setActiveTab}
        onTriggerDeploy={triggerVercelDeploy}
      />

      {/* Footer */}
      <footer className="border-t border-neutral-900/60 bg-neutral-950 py-8 mt-12 font-mono text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-1.5">
            <Laptop className="h-4 w-4" />
            <span>Developer Cockpit Panel — Cloud Sync Integration Active</span>
          </div>
          <div className="flex gap-4">
            <span>Server: aws-us-east-1a</span>
            <span>API SLA: 99.99%</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
