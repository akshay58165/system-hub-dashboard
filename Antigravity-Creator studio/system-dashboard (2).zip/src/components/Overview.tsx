import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  GitBranch, 
  Layers, 
  Database, 
  Activity, 
  Cpu, 
  CheckCircle2, 
  ArrowUpRight, 
  AlertTriangle, 
  Clock, 
  Zap, 
  Users, 
  Server, 
  Wifi 
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  BarChart, 
  Bar, 
  CartesianGrid 
} from 'recharts';
import { GitHubRepo, VercelProject, SupabaseProject, SystemEvent } from '../types';

interface OverviewProps {
  repos: GitHubRepo[];
  vercelProjects: VercelProject[];
  supabase: SupabaseProject;
  events: SystemEvent[];
  onTabChange: (tab: 'overview' | 'github' | 'vercel' | 'supabase') => void;
}

export default function Overview({ repos, vercelProjects, supabase, events, onTabChange }: OverviewProps) {
  // Compute some high-level metrics
  const totalStars = useMemo(() => repos.reduce((sum, r) => sum + r.stars, 0), [repos]);
  const totalIssues = useMemo(() => repos.reduce((sum, r) => sum + r.openIssues, 0), [repos]);
  
  const activeDeploymentsCount = useMemo(() => {
    return vercelProjects.filter(p => p.status === 'ready').length;
  }, [vercelProjects]);

  // Merge traffic data across projects for the combined chart
  const combinedTraffic = useMemo(() => {
    if (vercelProjects.length === 0) return [];
    const base = vercelProjects[0].analytics.traffic;
    return base.map((item, idx) => {
      let views = item.views;
      let visitors = item.visitors;
      for (let i = 1; i < vercelProjects.length; i++) {
        if (vercelProjects[i].analytics.traffic[idx]) {
          views += vercelProjects[i].analytics.traffic[idx].views;
          visitors += vercelProjects[i].analytics.traffic[idx].visitors;
        }
      }
      return {
        date: item.date,
        views,
        visitors,
      };
    });
  }, [vercelProjects]);

  return (
    <div className="space-y-6">
      {/* Integrated Pipeline Pipeline Flow */}
      <div id="pipeline-card" className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div>
            <h2 className="text-lg font-semibold text-neutral-100 tracking-tight flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              System Pipeline Flow
            </h2>
            <p className="text-xs text-neutral-400">Real-time interconnection of your repository, build engine, and server cluster.</p>
          </div>
          
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5 text-neutral-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>GitHub Live</span>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>Vercel Edge</span>
            </div>
            <div className="flex items-center gap-1.5 text-neutral-300">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>Supabase Primary</span>
            </div>
          </div>
        </div>

        {/* The Pipeline Connection Graphic */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center relative py-4">
          {/* GitHub Source Block */}
          <div 
            onClick={() => onTabChange('github')}
            className="md:col-span-1 p-4 bg-neutral-950 border border-neutral-800 rounded-lg hover:border-neutral-700 transition cursor-pointer flex flex-col items-center text-center group"
          >
            <div className="p-3 bg-neutral-900 rounded-full border border-neutral-800 group-hover:border-neutral-600 transition text-neutral-300 mb-2">
              <GitBranch className="h-5 w-5 text-neutral-300" />
            </div>
            <span className="text-xs font-mono font-semibold text-neutral-200">github.com</span>
            <span className="text-[10px] text-neutral-500 mt-1">{repos.length} Repositories</span>
            <span className="text-[10px] text-emerald-400 font-mono mt-0.5">Actions Status: Green</span>
          </div>

          {/* Connection Vector 1 */}
          <div className="hidden md:flex md:col-span-1 justify-center items-center">
            <div className="w-full relative h-1 bg-neutral-800 rounded-full">
              <motion.div 
                className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-emerald-500 to-blue-500 rounded-full"
                animate={{
                  left: ['0%', '100%'],
                  width: ['10%', '30%', '10%']
                }}
                transition={{
                  duration: 2.5,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
            </div>
          </div>

          {/* Vercel Host Block */}
          <div 
            onClick={() => onTabChange('vercel')}
            className="md:col-span-1 p-4 bg-neutral-950 border border-neutral-800 rounded-lg hover:border-neutral-700 transition cursor-pointer flex flex-col items-center text-center group"
          >
            <div className="p-3 bg-neutral-900 rounded-full border border-neutral-800 group-hover:border-neutral-600 transition text-neutral-300 mb-2">
              <Layers className="h-5 w-5 text-blue-400" />
            </div>
            <span className="text-xs font-mono font-semibold text-neutral-200">vercel.sh</span>
            <span className="text-[10px] text-neutral-500 mt-1">{vercelProjects.length} Custom domains</span>
            <span className="text-[10px] text-blue-400 font-mono mt-0.5">Global CDN Active</span>
          </div>

          {/* Connection Vector 2 */}
          <div className="hidden md:flex md:col-span-1 justify-center items-center">
            <div className="w-full relative h-1 bg-neutral-800 rounded-full">
              <motion.div 
                className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full"
                animate={{
                  left: ['0%', '100%'],
                  width: ['10%', '30%', '10%']
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear",
                  delay: 1.2
                }}
              />
            </div>
          </div>

          {/* Supabase Storage Block */}
          <div 
            onClick={() => onTabChange('supabase')}
            className="md:col-span-1 p-4 bg-neutral-950 border border-neutral-800 rounded-lg hover:border-neutral-700 transition cursor-pointer flex flex-col items-center text-center group"
          >
            <div className="p-3 bg-neutral-900 rounded-full border border-neutral-800 group-hover:border-neutral-600 transition text-neutral-300 mb-2">
              <Database className="h-5 w-5 text-emerald-400" />
            </div>
            <span className="text-xs font-mono font-semibold text-neutral-200">supabase.co</span>
            <span className="text-[10px] text-neutral-500 mt-1">{supabase.tables.length} Active Tables</span>
            <span className="text-[10px] text-emerald-400 font-mono mt-0.5">{supabase.metrics.activeConnections} Direct Conns</span>
          </div>
        </div>
      </div>

      {/* Grid of 4 Status Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Combined Traffic */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition">
          <div className="flex items-center justify-between text-neutral-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider font-mono">System Load / Users</span>
            <Users className="h-4 w-4 text-neutral-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">11,000</span>
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-0.5">
              +14.2%
            </span>
          </div>
          <div className="mt-2 text-xs text-neutral-500 font-mono flex items-center justify-between">
            <span>Monthly Active users</span>
            <span className="text-neutral-400">99.98% SLA</span>
          </div>
        </div>

        {/* Card 2: Serverless Latency */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition">
          <div className="flex items-center justify-between text-neutral-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider font-mono">API Response Speed</span>
            <Activity className="h-4 w-4 text-neutral-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">115ms</span>
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-0.5">
              -8% faster
            </span>
          </div>
          <div className="mt-2 text-xs text-neutral-500 font-mono flex items-center justify-between">
            <span>Avg Edge Function duration</span>
            <span className="text-emerald-400">Optimal</span>
          </div>
        </div>

        {/* Card 3: Supabase Database Pool */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition">
          <div className="flex items-center justify-between text-neutral-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider font-mono">Database Volume</span>
            <Database className="h-4 w-4 text-neutral-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">{supabase.metrics.dbSize}</span>
            <span className="text-xs text-neutral-400 font-mono">
              6,640 Rows
            </span>
          </div>
          <div className="mt-2 text-xs text-neutral-500 font-mono flex items-center justify-between">
            <span>Disk usage ratio</span>
            <span className="text-neutral-400">8.2% of allocated</span>
          </div>
        </div>

        {/* Card 4: Action Runs */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 hover:border-neutral-700 transition">
          <div className="flex items-center justify-between text-neutral-400 mb-3">
            <span className="text-xs font-medium uppercase tracking-wider font-mono">Git Repositories</span>
            <GitBranch className="h-4 w-4 text-neutral-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono tracking-tight text-white">{repos.length}</span>
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-0.5">
              All Green
            </span>
          </div>
          <div className="mt-2 text-xs text-neutral-500 font-mono flex items-center justify-between">
            <span>Total Starcount</span>
            <span className="text-yellow-500 font-mono">★ {totalStars}</span>
          </div>
        </div>
      </div>

      {/* Main Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Combined Traffic and Views (2 cols on large screen) */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-neutral-200">Integrated Web Analytics</h3>
              <p className="text-xs text-neutral-500">Aggregated viewer traffic across production domains (Vercel edge routers).</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-1 text-blue-400">
                <span className="h-1.5 w-1.5 bg-blue-500 rounded-full" />
                <span>Pageviews</span>
              </div>
              <div className="flex items-center gap-1 text-emerald-400">
                <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full" />
                <span>Unique Visitors</span>
              </div>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={combinedTraffic} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorVisitors" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#525252" fontSize={10} fontStyle="italic" />
                <YAxis stroke="#525252" fontSize={10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#171717', borderColor: '#262626', borderRadius: '8px' }}
                  labelStyle={{ color: '#a3a3a3', fontStyle: 'italic', fontSize: '11px' }}
                  itemStyle={{ fontSize: '12px' }}
                />
                <CartesianGrid stroke="#262626" strokeDasharray="3 3" />
                <Area type="monotone" dataKey="views" name="Pageviews" stroke="#3b82f6" fillOpacity={1} fill="url(#colorViews)" strokeWidth={2} />
                <Area type="monotone" dataKey="visitors" name="Unique Visitors" stroke="#10b981" fillOpacity={1} fill="url(#colorVisitors)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Server / Web Vitals & Hardware Speeds */}
        <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-neutral-200">Core Web Vitals</h3>
            <p className="text-xs text-neutral-500 font-mono">Performance scores from real user devices.</p>
          </div>

          {/* LCP Speedometer */}
          <div className="space-y-4 py-2">
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Largest Contentful Paint (LCP)</span>
                <span className="text-emerald-400 font-semibold">1.2s (Fast)</span>
              </div>
              <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '85%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">First Input Delay (FID)</span>
                <span className="text-emerald-400 font-semibold">12ms (Optimal)</span>
              </div>
              <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '95%' }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-neutral-400">Cumulative Layout Shift (CLS)</span>
                <span className="text-emerald-400 font-semibold">0.01 (Perfect)</span>
              </div>
              <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '98%' }} />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-800 grid grid-cols-2 gap-4">
            <div className="p-3 bg-neutral-900 rounded-lg text-center">
              <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider font-mono block">DB Connections</span>
              <span className="text-lg font-bold font-mono text-emerald-400 mt-1 block">{supabase.metrics.activeConnections}</span>
            </div>
            <div className="p-3 bg-neutral-900 rounded-lg text-center">
              <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider font-mono block">Node Latency</span>
              <span className="text-lg font-bold font-mono text-blue-400 mt-1 block">18ms</span>
            </div>
          </div>
        </div>
      </div>

      {/* Live Event Ticker Feed */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-neutral-200">Console Telemetry Log</h3>
            <p className="text-xs text-neutral-500">Consolidated real-time state telemetry from interconnected cloud services.</p>
          </div>
          <span className="px-2 py-0.5 bg-neutral-900 text-neutral-400 font-mono text-[10px] border border-neutral-800 rounded-full">
            {events.length} logs
          </span>
        </div>

        <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
          {events.map((evt) => (
            <div 
              key={evt.id} 
              className="p-3 bg-neutral-900/60 border border-neutral-800/80 rounded-lg flex items-start gap-3 hover:bg-neutral-900 transition text-xs"
            >
              {/* Event Badge Icon */}
              <div className="mt-0.5">
                {evt.type === 'success' && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                {evt.type === 'info' && <Wifi className="h-4 w-4 text-blue-400" />}
                {evt.type === 'warning' && <AlertTriangle className="h-4 w-4 text-amber-500" />}
                {evt.type === 'error' && <AlertTriangle className="h-4 w-4 text-rose-500" />}
              </div>

              {/* Event details */}
              <div className="flex-1 min-w-0">
                <p className="text-neutral-300 tracking-wide font-mono break-all">{evt.message}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`px-1.5 py-0.2 rounded font-mono text-[9px] uppercase font-semibold tracking-wider ${
                    evt.source === 'github' ? 'bg-neutral-800 text-neutral-300' :
                    evt.source === 'vercel' ? 'bg-blue-950 text-blue-400' :
                    evt.source === 'supabase' ? 'bg-emerald-950 text-emerald-400' :
                    'bg-neutral-800 text-neutral-400'
                  }`}>
                    {evt.source}
                  </span>
                  <span className="text-neutral-500 font-mono text-[10px] italic">
                    {new Date(evt.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
