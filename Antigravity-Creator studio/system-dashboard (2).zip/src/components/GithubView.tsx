import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  GitBranch, 
  GitCommit, 
  GitPullRequest, 
  Play, 
  Plus, 
  Terminal, 
  AlertCircle, 
  Star, 
  CheckCircle, 
  XCircle, 
  Loader2, 
  ExternalLink,
  GitMerge,
  Clock
} from 'lucide-react';
import { GitHubRepo, GitHubPR, GitHubWorkflow, GitHubCommit, SystemEvent } from '../types';

interface GithubViewProps {
  repos: GitHubRepo[];
  onAddEvent: (evt: SystemEvent) => void;
  onUpdateRepo: (repoId: string, updatedRepo: Partial<GitHubRepo>) => void;
  onTriggerDeploy: (projectName: string) => void;
}

export default function GithubView({ repos, onAddEvent, onUpdateRepo, onTriggerDeploy }: GithubViewProps) {
  const [selectedRepoId, setSelectedRepoId] = useState(repos[0]?.id || '');
  const [isNewPrOpen, setIsNewPrOpen] = useState(false);
  const [newPrTitle, setNewPrTitle] = useState('');
  const [newPrBranch, setNewPrBranch] = useState('feature/new-assets');
  
  // Terminal log status
  const [runningWorkflowId, setRunningWorkflowId] = useState<string | null>(null);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [logProgressIndex, setLogProgressIndex] = useState(0);

  const selectedRepo = repos.find(r => r.id === selectedRepoId) || repos[0];

  // Simulates a workflow run
  const triggerWorkflow = (workflowId: string, workflowName: string) => {
    if (runningWorkflowId) return; // Only one at a time

    // Set repo's workflow status to 'running'
    const updatedWorkflows = selectedRepo.workflows.map(wf => {
      if (wf.id === workflowId) {
        return { ...wf, status: 'running' as const, lastRun: new Date().toISOString() };
      }
      return wf;
    });
    onUpdateRepo(selectedRepo.id, { workflows: updatedWorkflows });

    setRunningWorkflowId(workflowId);
    setTerminalLogs(['[SYSTEM] Initializing remote Actions runner...', '[SYSTEM] Connecting to runner cluster node-us-east-12...']);
    setLogProgressIndex(0);

    onAddEvent({
      id: `evt-gh-wf-${Date.now()}`,
      source: 'github',
      type: 'info',
      message: `GitHub Actions: Triggered manual run for "${workflowName}" in repository "${selectedRepo.name}"`,
      timestamp: new Date().toISOString()
    });
  };

  // Streaming log lines
  useEffect(() => {
    if (!runningWorkflowId) return;

    const workflow = selectedRepo.workflows.find(w => w.id === runningWorkflowId);
    if (!workflow) return;

    const pipelineLogs = [
      'Checking out repository config details...',
      'Injecting developer keys from secure environment secrets storage...',
      'Detected Next.js ecosystem. Preparing server bundle hooks...',
      'Installing dependencies: npm run install-applet-dependencies...',
      'Verifying TypeScript types: npx tsc --noEmit... Passed!',
      'Running code quality checks: npm run lint... No warnings found.',
      'Initiating production build pipeline... Generating HTML, CSS & Edge bundles...',
      'Checking files size ratios: /dist output verified',
      'Deploying bundle webhook target triggers to Vercel CDN network...',
      'GitHub Actions deployment pipeline successfully completed! [Exit code: 0]'
    ];

    if (logProgressIndex < pipelineLogs.length) {
      const timer = setTimeout(() => {
        setTerminalLogs(prev => [...prev, `[LOG] ${pipelineLogs[logProgressIndex]}`]);
        setLogProgressIndex(prev => prev + 1);
      }, 900);
      return () => clearTimeout(timer);
    } else {
      // Completed successfully!
      const timer = setTimeout(() => {
        const updatedWorkflows = selectedRepo.workflows.map(wf => {
          if (wf.id === runningWorkflowId) {
            return { ...wf, status: 'success' as const, duration: '1m 15s' };
          }
          return wf;
        });
        onUpdateRepo(selectedRepo.id, { workflows: updatedWorkflows });
        setRunningWorkflowId(null);

        onAddEvent({
          id: `evt-gh-wf-sc-${Date.now()}`,
          source: 'github',
          type: 'success',
          message: `GitHub Actions: "${workflow.name}" completed successfully on branch "${selectedRepo.currentBranch}"`,
          timestamp: new Date().toISOString()
        });

        // Trigger Vercel Build integration as well!
        if (workflow.name === 'Production Deploy') {
          onTriggerDeploy(selectedRepo.name);
        }
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [runningWorkflowId, logProgressIndex]);

  // Create PR Action
  const handleCreatePr = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPrTitle.trim()) return;

    const newPr: GitHubPR = {
      id: `pr-${Date.now()}`,
      title: newPrTitle,
      number: selectedRepo.pullRequests.length + 43,
      author: 'typeakshay@gmail.com',
      status: 'open',
      createdAt: new Date().toISOString(),
      branch: newPrBranch,
    };

    onUpdateRepo(selectedRepo.id, {
      pullRequests: [newPr, ...selectedRepo.pullRequests],
    });

    onAddEvent({
      id: `evt-gh-pr-${Date.now()}`,
      source: 'github',
      type: 'info',
      message: `GitHub: Pull Request #${newPr.number} ("${newPr.title}") opened in ${selectedRepo.name}`,
      timestamp: new Date().toISOString(),
    });

    // Add simulated branch to repo branches if not already there
    if (!selectedRepo.branches.includes(newPrBranch)) {
      onUpdateRepo(selectedRepo.id, {
        branches: [...selectedRepo.branches, newPrBranch]
      });
    }

    setNewPrTitle('');
    setIsNewPrOpen(false);
  };

  // Merge PR Action
  const handleMergePr = (prId: string) => {
    const prToMerge = selectedRepo.pullRequests.find(p => p.id === prId);
    if (!prToMerge) return;

    // 1. Create a merge commit
    const mergeCommit: GitHubCommit = {
      id: `c-merge-${Date.now()}`,
      message: `Merge pull request #${prToMerge.number} from ${prToMerge.branch}`,
      author: 'typeakshay@gmail.com',
      date: new Date().toISOString(),
      hash: Math.random().toString(16).substring(2, 9),
    };

    const updatedPRs = selectedRepo.pullRequests.map(p => {
      if (p.id === prId) {
        return { ...p, status: 'merged' as const };
      }
      return p;
    });

    onUpdateRepo(selectedRepo.id, {
      pullRequests: updatedPRs,
      commits: [mergeCommit, ...selectedRepo.commits]
    });

    onAddEvent({
      id: `evt-gh-mrg-${Date.now()}`,
      source: 'github',
      type: 'success',
      message: `GitHub: Pull Request #${prToMerge.number} merged successfully to branch "main"`,
      timestamp: new Date().toISOString(),
    });

    // Also auto-trigger the Production Deploy Action!
    const deployWorkflow = selectedRepo.workflows.find(w => w.name === 'Production Deploy');
    if (deployWorkflow) {
      triggerWorkflow(deployWorkflow.id, deployWorkflow.name);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top repository picker */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-neutral-950 border border-neutral-800 rounded-xl p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-neutral-900 border border-neutral-800 rounded-lg text-neutral-300">
            <GitBranch className="h-5 w-5 text-neutral-200" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-neutral-100 font-mono">github.com/typeakshay</h2>
            <p className="text-xs text-neutral-400">Manage code, branches, and automation pipelines.</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          {repos.map(repo => (
            <button
              key={repo.id}
              onClick={() => setSelectedRepoId(repo.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition ${
                selectedRepoId === repo.id
                  ? 'bg-neutral-800 border-neutral-600 text-white'
                  : 'bg-neutral-900 border-neutral-850 text-neutral-400 hover:text-neutral-200 hover:border-neutral-700'
              }`}
            >
              {repo.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Repo General Status (Left 2 columns) */}
        <div className="lg:col-span-2 space-y-6">
          {/* Info Card */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5 relative overflow-hidden">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold font-mono text-white tracking-tight">{selectedRepo.name}</h3>
                  <span className="px-1.5 py-0.5 bg-neutral-900 border border-neutral-800 text-neutral-400 rounded text-[9px] font-mono font-semibold uppercase">
                    Public
                  </span>
                </div>
                <p className="text-xs text-neutral-400 mt-1 max-w-xl">{selectedRepo.description}</p>
              </div>

              <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 bg-neutral-900 border border-neutral-800 px-3 py-1 rounded-full">
                <Star className="h-3.5 w-3.5 text-yellow-500 fill-yellow-500" />
                <span>{selectedRepo.stars}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-5 border-t border-neutral-900">
              <div className="p-3 bg-neutral-900 rounded-lg">
                <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider font-mono">Current Branch</span>
                <span className="text-xs font-bold font-mono text-white mt-1 flex items-center gap-1">
                  <GitBranch className="h-3 w-3 text-blue-400" />
                  {selectedRepo.currentBranch}
                </span>
              </div>

              <div className="p-3 bg-neutral-900 rounded-lg">
                <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider font-mono">Open PRs</span>
                <span className="text-xs font-bold font-mono text-white mt-1 flex items-center gap-1">
                  <GitPullRequest className="h-3 w-3 text-emerald-400" />
                  {selectedRepo.pullRequests.filter(p => p.status === 'open').length} active
                </span>
              </div>

              <div className="p-3 bg-neutral-900 rounded-lg">
                <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider font-mono">Open Issues</span>
                <span className="text-xs font-bold font-mono text-white mt-1 flex items-center gap-1">
                  <AlertCircle className="h-3 w-3 text-amber-500" />
                  {selectedRepo.openIssues} tickets
                </span>
              </div>

              <div className="p-3 bg-neutral-900 rounded-lg">
                <span className="text-[10px] uppercase font-semibold text-neutral-500 tracking-wider font-mono">Total Branches</span>
                <span className="text-xs font-bold font-mono text-white mt-1">
                  {selectedRepo.branches.length} environments
                </span>
              </div>
            </div>
          </div>

          {/* GitHub Actions / Workflows */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-neutral-200">GitHub Actions</h3>
                <p className="text-xs text-neutral-500 font-mono">CI/CD build, audit, and deployment orchestration workflows.</p>
              </div>

              <button 
                onClick={() => {
                  const buildWf = selectedRepo.workflows.find(w => w.name === 'Production Deploy');
                  if (buildWf) {
                    triggerWorkflow(buildWf.id, buildWf.name);
                  }
                }}
                disabled={runningWorkflowId !== null}
                className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 disabled:opacity-50 border border-neutral-800 hover:border-neutral-750 text-white rounded-lg text-xs font-mono font-medium flex items-center gap-1.5 transition"
              >
                {runningWorkflowId ? (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin text-blue-400" />
                    <span>Deploy Running...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-3 w-3 text-emerald-400 fill-emerald-400" />
                    <span>Run Prod Deploy</span>
                  </>
                )}
              </button>
            </div>

            {/* Workflows List */}
            <div className="space-y-3">
              {selectedRepo.workflows.map(wf => (
                <div key={wf.id} className="p-3 bg-neutral-900 rounded-lg border border-neutral-850 flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      {wf.status === 'success' && <CheckCircle className="h-4 w-4 text-emerald-500" />}
                      {wf.status === 'failure' && <XCircle className="h-4 w-4 text-rose-500" />}
                      {wf.status === 'running' && <Loader2 className="h-4 w-4 text-blue-400 animate-spin" />}
                      {wf.status === 'queued' && <Clock className="h-4 w-4 text-neutral-500" />}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-neutral-200 font-mono">{wf.name}</span>
                        <span className="text-[10px] text-neutral-500 font-mono">#{wf.commitHash}</span>
                      </div>
                      <p className="text-[11px] text-neutral-400 font-mono mt-0.5">
                        Duration: {wf.duration} • Triggered {new Date(wf.lastRun).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {wf.status !== 'running' && (
                      <button 
                        onClick={() => triggerWorkflow(wf.id, wf.name)}
                        className="px-2 py-1 bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-neutral-200 text-[10px] font-mono rounded"
                      >
                        Run workflow
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Running Terminal Visual Logs */}
            <AnimatePresence>
              {(runningWorkflowId || terminalLogs.length > 0) && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 border border-neutral-800 rounded-lg overflow-hidden"
                >
                  <div className="bg-neutral-900 border-b border-neutral-800 px-3 py-1.5 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                    <div className="flex items-center gap-1.5">
                      <Terminal className="h-3.5 w-3.5 text-neutral-400" />
                      <span>Actions Stream Runner Console</span>
                    </div>
                    {runningWorkflowId ? (
                      <span className="text-blue-400 flex items-center gap-1 animate-pulse">
                        <Loader2 className="h-3 w-3 animate-spin" /> RUNNING
                      </span>
                    ) : (
                      <span className="text-emerald-500">FINISHED (0)</span>
                    )}
                  </div>
                  <div className="bg-neutral-950 p-3 h-48 overflow-y-auto font-mono text-[10px] text-neutral-400 space-y-1">
                    {terminalLogs.map((log, i) => (
                      <div key={i} className={`whitespace-pre-wrap ${log.includes('[SYSTEM]') ? 'text-blue-400 font-semibold' : log.includes('successfully') ? 'text-emerald-400' : 'text-neutral-400'}`}>
                        {log}
                      </div>
                    ))}
                    {runningWorkflowId && (
                      <span className="inline-block h-3 w-1.5 bg-neutral-400 animate-pulse ml-1" />
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* PRs and Commits (Right sidebar) */}
        <div className="space-y-6">
          {/* Pull Requests */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-neutral-200">Pull Requests</h3>
              <button 
                onClick={() => setIsNewPrOpen(!isNewPrOpen)}
                className="p-1 bg-neutral-900 hover:bg-neutral-800 text-neutral-300 rounded border border-neutral-800 transition"
                title="Create Pull Request"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* PR Create Form */}
            {isNewPrOpen && (
              <motion.form 
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                onSubmit={handleCreatePr}
                className="mb-4 p-3 bg-neutral-900 border border-neutral-800 rounded-lg space-y-3"
              >
                <div>
                  <label className="block text-[10px] uppercase font-mono text-neutral-500">PR Title</label>
                  <input 
                    type="text" 
                    required
                    placeholder="feat: add custom webhooks"
                    value={newPrTitle}
                    onChange={(e) => setNewPrTitle(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-700 outline-none text-xs rounded px-2.5 py-1.5 mt-1 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase font-mono text-neutral-500">Target Branch</label>
                  <select 
                    value={newPrBranch}
                    onChange={(e) => setNewPrBranch(e.target.value)}
                    className="w-full bg-neutral-950 border border-neutral-800 focus:border-neutral-700 outline-none text-xs rounded px-2.5 py-1.5 mt-1 text-white font-mono"
                  >
                    <option value="feature/stripe-billing">feature/stripe-billing</option>
                    <option value="feature/supabase-schema">feature/supabase-schema</option>
                    <option value="feature/new-assets">feature/new-assets</option>
                    <option value="fix/cache-policy">fix/cache-policy</option>
                  </select>
                </div>
                <div className="flex justify-end gap-2 text-[10px]">
                  <button 
                    type="button" 
                    onClick={() => setIsNewPrOpen(false)}
                    className="px-2.5 py-1 text-neutral-500 hover:text-neutral-300 font-mono"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-600 text-black font-semibold rounded font-mono"
                  >
                    Open PR
                  </button>
                </div>
              </motion.form>
            )}

            {/* PR list */}
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {selectedRepo.pullRequests.length === 0 ? (
                <p className="text-xs text-neutral-500 italic font-mono text-center py-4">No open pull requests found</p>
              ) : (
                selectedRepo.pullRequests.map(pr => (
                  <div key={pr.id} className="p-3 bg-neutral-900 border border-neutral-850 rounded-lg">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <span className="text-[11px] font-bold text-neutral-200 hover:text-blue-400 cursor-pointer block truncate font-mono">
                          #{pr.number} {pr.title}
                        </span>
                        <span className="text-[10px] text-neutral-500 font-mono mt-0.5 block">
                          by {pr.author} • {pr.branch}
                        </span>
                      </div>

                      <span className={`px-1.5 py-0.2 rounded font-mono text-[9px] uppercase font-semibold ${
                        pr.status === 'open' ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-900' :
                        pr.status === 'merged' ? 'bg-purple-950/80 text-purple-400 border border-purple-900' :
                        'bg-neutral-800 text-neutral-400'
                      }`}>
                        {pr.status}
                      </span>
                    </div>

                    {pr.status === 'open' && (
                      <div className="mt-2.5 pt-2 border-t border-neutral-850/50 flex justify-end">
                        <button 
                          onClick={() => handleMergePr(pr.id)}
                          className="px-2 py-0.5 bg-neutral-950 border border-neutral-800 hover:border-neutral-750 hover:text-white text-neutral-400 text-[10px] font-mono rounded flex items-center gap-1 transition"
                        >
                          <GitMerge className="h-3 w-3 text-purple-400" />
                          <span>Merge Pull Request</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Commits List */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5">
            <h3 className="text-sm font-semibold text-neutral-200 mb-3">Commit History</h3>
            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {selectedRepo.commits.map(commit => (
                <div key={commit.id} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="p-1 bg-neutral-900 rounded-full border border-neutral-800">
                      <GitCommit className="h-3.5 w-3.5 text-neutral-400" />
                    </div>
                    <div className="flex-1 w-[1px] bg-neutral-800 min-h-[20px]" />
                  </div>

                  <div className="flex-1 min-w-0 pb-3">
                    <p className="text-xs text-neutral-200 truncate font-mono">{commit.message}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-neutral-500 font-mono">{commit.author}</span>
                      <span className="text-neutral-600 font-mono">•</span>
                      <span className="text-[9px] text-neutral-500 font-mono uppercase bg-neutral-900 px-1 py-0.2 rounded font-semibold border border-neutral-850">
                        {commit.hash}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
